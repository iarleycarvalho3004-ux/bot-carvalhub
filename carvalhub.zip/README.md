# CARVALHUB (SERVER BUILDER)

Bot que monta a estrutura de um servidor Discord (categorias, canais, cargos) com prévia e confirmação.
Status: **Etapa 1** (bot funcional: `/painel`, `/ajuda`, `/status`). Veja `docs/` para a arquitetura.

## 1. Criar o bot no Discord (Developer Portal)

1. Acesse https://discord.com/developers/applications → **New Application** → nome `CARVALHUB`.
2. Aba **General Information**: envie a logo em *App Icon*.
3. Aba **Bot**: clique em **Reset Token** e copie o token (guarde só no `.env`).
   Deixe **todas as Privileged Gateway Intents desligadas** (o bot só usa `Guilds`).
4. Aba **OAuth2 → URL Generator**:
   - Scopes: `bot` e `applications.commands`
   - Bot Permissions (mínimas para as próximas etapas): `Manage Roles`, `Manage Channels`, `View Channels`
5. Abra a URL gerada e adicione o bot a um **servidor de teste vazio**.
6. No servidor, mova o cargo do bot para o topo da lista de cargos (abaixo do seu).

## 2. Rodar pelo celular (GitHub Codespaces)

1. Crie uma conta no GitHub e um repositório **privado** com estes arquivos.
2. No repositório: **Code → Codespaces → Create codespace**.
3. No terminal do Codespace:
   ```
   pip install -r requirements.txt
   cp .env.example .env
   ```
   Abra o `.env`, cole o token em `DISCORD_TOKEN` e salve.
4. Rode: `python bot.py`
5. No Discord (servidor de teste), digite `/` e use `/painel`, `/ajuda`, `/status`.

## 3. Testes

```
python -m pytest -q
```

## 4. Teste de persistência (manual)

1. Rode o bot e use `/painel` (grava o servidor no banco).
2. Pare (Ctrl+C) e rode de novo. O log não deve mostrar migração nova e `/status` deve mostrar banco OK.

## Segurança

- O token fica **somente** no `.env` (já no `.gitignore`). Se vazar, faça **Reset Token**.
- Os logs mascaram o token automaticamente.
