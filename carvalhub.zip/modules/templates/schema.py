"""Schema pydantic dos templates (Etapa 0).

Define e valida a estrutura dos templates. Não importa discord.py.
A lógica de resolução (porte/módulos/estilo de nomes) entra na Etapa 2/3.
"""
from __future__ import annotations

import re
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

EVERYONE = "@everyone"
ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}$")
KEY_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,47}$")

MAX_ROLES = 250
MAX_CHANNELS_TOTAL = 500  # canais + categorias
MAX_CHANNELS_PER_CATEGORY = 50
MAX_NAME = 100
MAX_TOPIC = 1024


class Size(str, Enum):
    compact = "compact"
    balanced = "balanced"
    full = "full"


SIZE_ORDER = {Size.compact: 0, Size.balanced: 1, Size.full: 2}


def size_includes(selected: Size, min_size: Size) -> bool:
    """Um item com min_size aparece quando o porte escolhido é >= min_size."""
    return SIZE_ORDER[selected] >= SIZE_ORDER[min_size]


class Family(str, Enum):
    community = "community"
    gaming = "gaming"
    creator = "creator"
    education = "education"
    business = "business"
    specialized = "specialized"


class Status(str, Enum):
    complete = "complete"
    experimental = "experimental"
    in_development = "in_development"


class ChannelType(str, Enum):
    text = "text"
    voice = "voice"
    announcement = "announcement"  # exige modo Comunidade
    forum = "forum"  # exige modo Comunidade
    stage = "stage"  # exige modo Comunidade


COMMUNITY_ONLY_TYPES = {ChannelType.announcement, ChannelType.forum, ChannelType.stage}

# Permissões aceitas no schema (nomes iguais aos de discord.Permissions).
SAFE_PERMISSIONS = frozenset({
    "view_channel", "send_messages", "send_messages_in_threads", "read_message_history",
    "add_reactions", "embed_links", "attach_files", "use_external_emojis",
    "create_public_threads", "create_private_threads", "use_application_commands",
    "connect", "speak", "stream", "use_voice_activation", "priority_speaker",
    "change_nickname", "create_instant_invite", "request_to_speak",
    "create_polls", "send_polls",
})
SENSITIVE_PERMISSIONS = frozenset({
    "administrator", "manage_guild", "manage_roles", "manage_channels",
    "manage_webhooks", "manage_messages", "manage_threads", "manage_nicknames",
    "kick_members", "ban_members", "moderate_members", "mention_everyone",
    "mute_members", "deafen_members", "move_members", "view_audit_log",
    "manage_events", "manage_expressions",
})
ALL_PERMISSIONS = SAFE_PERMISSIONS | SENSITIVE_PERMISSIONS


class _Base(BaseModel):
    model_config = ConfigDict(extra="forbid")


def _check_perms(names: list[str]) -> list[str]:
    unknown = sorted(set(names) - ALL_PERMISSIONS)
    if unknown:
        raise ValueError(f"permissões desconhecidas: {unknown}")
    return names


class Overwrite(_Base):
    role: str  # chave de cargo ou "@everyone"
    allow: list[str] = Field(default_factory=list)
    deny: list[str] = Field(default_factory=list)

    @field_validator("allow", "deny")
    @classmethod
    def _perms(cls, v: list[str]) -> list[str]:
        return _check_perms(v)

    @model_validator(mode="after")
    def _no_conflict(self) -> "Overwrite":
        both = set(self.allow) & set(self.deny)
        if both:
            raise ValueError(f"permissão em allow e deny ao mesmo tempo: {sorted(both)}")
        return self


class Role(_Base):
    key: str = Field(pattern=KEY_RE.pattern)
    name: str = Field(min_length=1, max_length=MAX_NAME)
    color: int = Field(default=0, ge=0, le=0xFFFFFF)
    hoist: bool = False
    mentionable: bool = False
    permissions: list[str] = Field(default_factory=list)
    min_size: Size = Size.compact
    owner_like: bool = False  # único cargo que pode (com aval) levar administrator
    sensitive_ack: bool = False  # confirma conscientemente permissões sensíveis

    @field_validator("permissions")
    @classmethod
    def _perms(cls, v: list[str]) -> list[str]:
        return _check_perms(v)

    @model_validator(mode="after")
    def _sensitive(self) -> "Role":
        sensitive = set(self.permissions) & SENSITIVE_PERMISSIONS
        if "administrator" in sensitive and not self.owner_like:
            raise ValueError(
                f"cargo '{self.key}': administrator só é permitido no cargo owner_like"
            )
        if sensitive and not self.sensitive_ack:
            raise ValueError(
                f"cargo '{self.key}': permissões sensíveis {sorted(sensitive)} exigem sensitive_ack=true"
            )
        return self


class Channel(_Base):
    key: str = Field(pattern=KEY_RE.pattern)
    name: str = Field(min_length=1, max_length=MAX_NAME)
    type: ChannelType = ChannelType.text
    topic: str | None = Field(default=None, max_length=MAX_TOPIC)
    emoji: str | None = None
    min_size: Size = Size.compact
    module: str | None = None
    overwrites: list[Overwrite] = Field(default_factory=list)
    slowmode: int = Field(default=0, ge=0, le=21600)
    user_limit: int = Field(default=0, ge=0, le=99)  # só voz
    nsfw: bool = False

    @model_validator(mode="after")
    def _type_rules(self) -> "Channel":
        if self.user_limit and self.type not in (ChannelType.voice, ChannelType.stage):
            raise ValueError(f"canal '{self.key}': user_limit só vale para voz/palco")
        return self


class Category(_Base):
    key: str = Field(pattern=KEY_RE.pattern)
    name: str = Field(min_length=1, max_length=MAX_NAME)
    emoji: str | None = None
    min_size: Size = Size.compact
    module: str | None = None
    overwrites: list[Overwrite] = Field(default_factory=list)
    channels: list[Channel] = Field(default_factory=list)

    @field_validator("channels")
    @classmethod
    def _limit(cls, v: list[Channel]) -> list[Channel]:
        if len(v) > MAX_CHANNELS_PER_CATEGORY:
            raise ValueError(f"máximo de {MAX_CHANNELS_PER_CATEGORY} canais por categoria")
        return v


class Module(_Base):
    key: str = Field(pattern=KEY_RE.pattern)
    name: str
    description: str = ""
    default_enabled: bool = False
    requires_external: bool = False
    implemented: bool = True  # False => exibido como "em breve", não selecionável


class InitialMessage(_Base):
    channel: str  # chave de canal
    content: str = Field(min_length=1, max_length=2000)
    module: str | None = None


class Template(_Base):
    schema_version: Literal[1] = 1
    id: str = Field(pattern=ID_RE.pattern)
    name: str = Field(min_length=1, max_length=80)
    description: str = Field(min_length=1, max_length=400)
    family: Family
    status: Status
    audience: str = ""
    recommended_size: Size = Size.balanced
    roles: list[Role] = Field(default_factory=list)  # ordem = hierarquia (topo primeiro)
    categories: list[Category] = Field(default_factory=list)
    modules: list[Module] = Field(default_factory=list)
    initial_messages: list[InitialMessage] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)

    # ---- contagens (calculadas, nunca digitadas) ----
    @property
    def channel_count(self) -> int:
        return sum(len(c.channels) for c in self.categories)

    @property
    def element_count(self) -> int:
        return len(self.roles) + len(self.categories) + self.channel_count

    @model_validator(mode="after")
    def _integrity(self) -> "Template":
        role_keys = [r.key for r in self.roles]
        cat_keys = [c.key for c in self.categories]
        chan_keys = [ch.key for c in self.categories for ch in c.channels]
        mod_keys = [m.key for m in self.modules]
        for label, keys in (("cargos", role_keys), ("categorias", cat_keys),
                            ("canais", chan_keys), ("módulos", mod_keys)):
            dup = {k for k in keys if keys.count(k) > 1}
            if dup:
                raise ValueError(f"chaves duplicadas em {label}: {sorted(dup)}")

        if len(self.roles) > MAX_ROLES:
            raise ValueError(f"máximo de {MAX_ROLES} cargos")
        if len(self.categories) + len(chan_keys) > MAX_CHANNELS_TOTAL:
            raise ValueError(f"máximo de {MAX_CHANNELS_TOTAL} canais+categorias")
        if sum(r.owner_like for r in self.roles) > 1:
            raise ValueError("no máximo um cargo owner_like")

        valid_roles = set(role_keys) | {EVERYONE}
        valid_mods = set(mod_keys)

        def check_ow(owner: str, ows: list[Overwrite]) -> None:
            for ow in ows:
                if ow.role not in valid_roles:
                    raise ValueError(f"{owner}: overwrite referencia cargo inexistente '{ow.role}'")

        for cat in self.categories:
            check_ow(f"categoria '{cat.key}'", cat.overwrites)
            if cat.module and cat.module not in valid_mods:
                raise ValueError(f"categoria '{cat.key}': módulo inexistente '{cat.module}'")
            for ch in cat.channels:
                check_ow(f"canal '{ch.key}'", ch.overwrites)
                if ch.module and ch.module not in valid_mods:
                    raise ValueError(f"canal '{ch.key}': módulo inexistente '{ch.module}'")

        chan_set = set(chan_keys)
        for m in self.initial_messages:
            if m.channel not in chan_set:
                raise ValueError(f"mensagem inicial referencia canal inexistente '{m.channel}'")
            if m.module and m.module not in valid_mods:
                raise ValueError(f"mensagem inicial: módulo inexistente '{m.module}'")

        needs_community = any(
            ch.type in COMMUNITY_ONLY_TYPES for c in self.categories for ch in c.channels
        )
        if needs_community and not any("comunidade" in w.lower() or "community" in w.lower()
                                       for w in self.warnings):
            raise ValueError(
                "template usa canais anúncio/fórum/palco: inclua em 'warnings' o requisito do modo Comunidade"
            )
        return self
