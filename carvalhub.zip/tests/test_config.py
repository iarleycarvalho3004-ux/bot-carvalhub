import pytest

from config import Settings
from utils.errors import ConfigError

FAKE_TOKEN = "A" * 24 + "." + "B" * 6 + "." + "C" * 30


def env(**kw):
    base = {"DISCORD_TOKEN": FAKE_TOKEN}
    base.update(kw)
    return base


def test_defaults():
    s = Settings.from_env(env(), load_dotenv_file=False)
    assert s.environment == "development"
    assert s.log_level == "INFO"
    assert s.database_url.startswith("sqlite:///")


@pytest.mark.parametrize("value", [None, "", "   ", "COLE_SEU_TOKEN_AQUI"])
def test_missing_or_placeholder_token_fails(value):
    e = {} if value is None else {"DISCORD_TOKEN": value}
    with pytest.raises(ConfigError, match="DISCORD_TOKEN"):
        Settings.from_env(e, load_dotenv_file=False)


def test_invalid_environment_and_log_level():
    with pytest.raises(ConfigError, match="ENVIRONMENT"):
        Settings.from_env(env(ENVIRONMENT="staging"), load_dotenv_file=False)
    with pytest.raises(ConfigError, match="LOG_LEVEL"):
        Settings.from_env(env(LOG_LEVEL="FALAR"), load_dotenv_file=False)


def test_values_are_normalized():
    s = Settings.from_env(env(ENVIRONMENT="Production", LOG_LEVEL="debug"), load_dotenv_file=False)
    assert s.environment == "production" and s.log_level == "DEBUG"


def test_token_not_in_repr():
    s = Settings.from_env(env(), load_dotenv_file=False)
    assert FAKE_TOKEN not in repr(s)
    assert FAKE_TOKEN not in str(s)
