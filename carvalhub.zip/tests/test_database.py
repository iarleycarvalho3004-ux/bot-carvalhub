import asyncio

import pytest

from database.connection import Database
from utils.errors import ConfigError, DatabaseError


def run(coro):
    return asyncio.run(coro)


def url(tmp_path):
    return f"sqlite:///{tmp_path / 'sub' / 'test.db'}"


def test_postgres_url_rejected_for_now():
    with pytest.raises(ConfigError):
        Database("postgresql://u:p@h/db")


def test_migrate_creates_tables_and_is_idempotent(tmp_path):
    async def go():
        db = Database(url(tmp_path))
        await db.connect()
        first = await db.migrate()
        second = await db.migrate()
        tables = {r["name"] for r in await db.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        await db.close()
        return first, second, tables

    first, second, tables = run(go())
    assert first == ["0001_initial"]
    assert second == []
    assert {"guild_settings", "audit_log", "schema_migrations"} <= tables


def test_ping_and_not_connected_error(tmp_path):
    async def go():
        db = Database(url(tmp_path))
        with pytest.raises(DatabaseError):
            await db.fetchone("SELECT 1")
        assert await db.ping() is False
        await db.connect()
        ok = await db.ping()
        await db.close()
        return ok

    assert run(go()) is True


def test_data_persists_after_restart(tmp_path):
    """Critério da Etapa 1: dados persistem após reinício."""
    guild_id = 1234567890123456789  # snowflake de 64 bits

    async def first_run():
        db = Database(url(tmp_path))
        await db.connect()
        await db.migrate()
        await db.ensure_guild(guild_id)
        await db.audit("teste", guild_id, 42)
        await db.close()

    async def second_run():
        db = Database(url(tmp_path))
        await db.connect()
        applied = await db.migrate()
        g = await db.fetchone("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,))
        a = await db.fetchall("SELECT * FROM audit_log")
        await db.close()
        return applied, g, a

    run(first_run())
    applied, g, a = run(second_run())
    assert applied == []  # nada a migrar de novo
    assert g["guild_id"] == guild_id and g["language"] == "pt"
    assert len(a) == 1 and a[0]["action"] == "teste" and a[0]["user_id"] == 42


def test_ensure_guild_is_upsert(tmp_path):
    async def go():
        db = Database(url(tmp_path))
        await db.connect()
        await db.migrate()
        await db.ensure_guild(1)
        await db.ensure_guild(1)
        rows = await db.fetchall("SELECT * FROM guild_settings")
        await db.close()
        return rows

    assert len(run(go())) == 1


def test_bad_sql_raises_database_error(tmp_path):
    async def go():
        db = Database(url(tmp_path))
        await db.connect()
        try:
            await db.execute("INSERT INTO tabela_que_nao_existe VALUES (1)")
        finally:
            await db.close()

    with pytest.raises(DatabaseError):
        run(go())
