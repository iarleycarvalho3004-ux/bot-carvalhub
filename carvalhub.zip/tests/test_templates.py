import copy
import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from modules.templates.schema import Size, Template, size_includes

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE_FILES = sorted((ROOT / "templates").rglob("*.json"))


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


@pytest.fixture
def base():
    return load(ROOT / "templates" / "community" / "comunidade-geral.json")


def test_there_is_at_least_one_template():
    assert TEMPLATE_FILES


@pytest.mark.parametrize("path", TEMPLATE_FILES, ids=lambda p: p.name)
def test_all_template_files_validate(path):
    t = Template.model_validate(load(path))
    assert t.id == path.stem


def test_ids_unique():
    ids = [Template.model_validate(load(p)).id for p in TEMPLATE_FILES]
    assert len(ids) == len(set(ids))


def test_counts_are_computed(base):
    t = Template.model_validate(base)
    assert t.element_count == len(t.roles) + len(t.categories) + t.channel_count == 3 + 4 + 7


def test_size_ordering():
    assert size_includes(Size.full, Size.balanced)
    assert size_includes(Size.balanced, Size.balanced)
    assert not size_includes(Size.compact, Size.balanced)


def test_duplicate_channel_key_rejected(base):
    d = copy.deepcopy(base)
    d["categories"][1]["channels"][1]["key"] = "geral"
    with pytest.raises(ValidationError, match="duplicadas"):
        Template.model_validate(d)


def test_overwrite_unknown_role_rejected(base):
    d = copy.deepcopy(base)
    d["categories"][3]["overwrites"][1]["role"] = "fantasma"
    with pytest.raises(ValidationError, match="inexistente"):
        Template.model_validate(d)


def test_administrator_on_regular_role_rejected(base):
    d = copy.deepcopy(base)
    d["roles"][2]["permissions"].append("administrator")
    d["roles"][2]["sensitive_ack"] = True
    with pytest.raises(ValidationError, match="owner_like"):
        Template.model_validate(d)


def test_sensitive_without_ack_rejected(base):
    d = copy.deepcopy(base)
    d["roles"][1]["sensitive_ack"] = False
    with pytest.raises(ValidationError, match="sensitive_ack"):
        Template.model_validate(d)


def test_unknown_permission_rejected(base):
    d = copy.deepcopy(base)
    d["roles"][2]["permissions"].append("voar")
    with pytest.raises(ValidationError, match="desconhecidas"):
        Template.model_validate(d)


def test_color_out_of_range_rejected(base):
    d = copy.deepcopy(base)
    d["roles"][2]["color"] = 0x1000000
    with pytest.raises(ValidationError):
        Template.model_validate(d)


def test_bad_id_rejected(base):
    d = copy.deepcopy(base)
    d["id"] = "Comunidade Geral!"
    with pytest.raises(ValidationError):
        Template.model_validate(d)


def test_unknown_module_rejected(base):
    d = copy.deepcopy(base)
    d["categories"][3]["module"] = "nao_existe"
    with pytest.raises(ValidationError, match="módulo inexistente"):
        Template.model_validate(d)


def test_forum_requires_community_warning(base):
    d = copy.deepcopy(base)
    d["categories"][1]["channels"].append({"key": "forum1", "name": "duvidas", "type": "forum"})
    with pytest.raises(ValidationError, match="Comunidade"):
        Template.model_validate(d)
    d["warnings"].append("Fórum exige o modo Comunidade ativo no servidor.")
    Template.model_validate(d)


def test_extra_fields_forbidden(base):
    d = copy.deepcopy(base)
    d["campo_novo"] = 1
    with pytest.raises(ValidationError):
        Template.model_validate(d)
