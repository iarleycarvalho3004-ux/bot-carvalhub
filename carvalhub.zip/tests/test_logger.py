import logging

from utils.logger import REDACTED, RedactingFormatter, setup_logging

FAKE_TOKEN = "A" * 24 + "." + "B" * 6 + "." + "C" * 30


def test_formatter_redacts_exact_secret_and_token_pattern():
    f = RedactingFormatter("%(message)s", secrets=["segredo-xyz"])
    r = logging.LogRecord("t", logging.INFO, __file__, 1, "valor segredo-xyz e %s", (FAKE_TOKEN,), None)
    out = f.format(r)
    assert "segredo-xyz" not in out
    assert FAKE_TOKEN not in out
    assert REDACTED in out


def test_formatter_redacts_tracebacks():
    f = RedactingFormatter("%(message)s", secrets=[FAKE_TOKEN])
    try:
        raise ValueError(f"falhou com {FAKE_TOKEN}")
    except ValueError:
        import sys
        r = logging.LogRecord("t", logging.ERROR, __file__, 1, "erro", (), sys.exc_info())
    assert FAKE_TOKEN not in f.format(r)


def test_setup_logging_writes_file_without_token(tmp_path):
    setup_logging("INFO", tmp_path, secrets=[FAKE_TOKEN])
    logging.getLogger("teste").info("token=%s", FAKE_TOKEN)
    for h in logging.getLogger().handlers:
        h.flush()
    content = (tmp_path / "server_builder.log").read_text(encoding="utf-8")
    assert "token=" in content
    assert FAKE_TOKEN not in content


def test_setup_logging_is_idempotent(tmp_path):
    setup_logging("INFO", tmp_path)
    n = len(logging.getLogger().handlers)
    setup_logging("INFO", tmp_path)
    assert len(logging.getLogger().handlers) == n
