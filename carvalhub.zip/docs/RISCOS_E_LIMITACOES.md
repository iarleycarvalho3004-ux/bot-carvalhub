# Riscos técnicos e limitações conhecidas da API

> Valores baseados no meu conhecimento da documentação do Discord. **Não foram verificados contra a API real nesta etapa** (sem token/rede). A Etapa 1 e a Etapa 5 incluem testes em servidor real para confirmar. Limites mudam: conferir a documentação oficial antes de fixar constantes.

## Limitações da plataforma

| Item | Limite / comportamento | Alternativa / mitigação |
|---|---|---|
| Criar servidor | Bots não devem criar servidores (recurso restrito/descontinuado) | Usuário cria servidor vazio e convida o bot (já previsto) |
| Cargos | ~250 por servidor | Validação do plano antes de confirmar |
| Canais + categorias | ~500 por servidor; 50 canais por categoria | Idem; sugerir porte menor |
| Hierarquia de cargos | Bot só gerencia cargos abaixo do seu cargo mais alto; não pode conceder permissões que ele mesmo não tem | Instruir o admin a mover o cargo do bot para o topo (abaixo do dono); validar antes |
| Canais Anúncio/Fórum/Palco | Exigem modo **Comunidade** no servidor | Detectar o recurso `COMMUNITY`; se ausente, oferecer converter em texto ou avisar. O bot não ativará Comunidade sozinho. |
| Nome de canal de texto | Minúsculas, sem espaços; caracteres como `・ ┃ ﹒ »` normalmente aceitos, mas o Discord normaliza | Normalizador de nomes + testes reais |
| Nomes ≤100 caracteres | Cargo/canal/categoria | Validação |
| Rate limits | Criação em massa pode gerar 429; limites por rota não totalmente documentados | discord.py respeita 429; pausa entre criações; progresso tolerante; **não contornar** |
| Mensagens ephemeral | Só existem como resposta a interações; token de interação vale ~15 min | Sessão no banco; reabrir via /painel |
| Select menu | ≤25 opções; ≤5 linhas de componentes por mensagem; ≤5 botões por linha | Paginação |
| Modal | Poucos campos (5 linhas) | Dividir edições em etapas |
| Embeds | Título 256, descrição 4096, 25 campos, 6000 total por mensagem, 10 embeds | Prévia paginada (usamos margem) |
| `custom_id` | ≤100 caracteres | IDs curtos de sessão |
| Resposta a interações | Responder em 3 s, senão `defer` | `defer` em operações longas |
| Cargos por reação/menus | Exigem mensagem persistente e tratamento de permissões | Módulo opcional posterior (Etapa 9) |

## Riscos de projeto e mitigação

1. **Falha parcial durante criação** — registro imediato de IDs; retomada por `plan_key`; limpeza só do que foi criado.
2. **Duplicação ao retomar** — UNIQUE(operation_id, plan_key) + checagem prévia.
3. **Permissões excessivas** — lista de permissões perigosas, `sensitive_ack`, `administrator` bloqueado por padrão.
4. **Sequestro de painel** — validação de `user_id` em cada interação.
5. **Reinício no meio da configuração** — sessões e views persistentes.
6. **Reinício no meio da execução** — operação `running` é detectada no start e marcada `partial`, oferecendo retomar.
7. **Divergência prévia × execução** — executor consome o mesmo `BuildPlan`; hash do plano gravado na operação; teste de equivalência.
8. **Vazamento de token** — logger com filtro de mascaramento; `.env` no `.gitignore`.
9. **Compatibilidade SQLite × PostgreSQL** — SQL portável, camada de conexão única, testes nos dois na Etapa 10.
10. **Limites de tamanho da prévia** — paginador testado com planos máximos.
11. **IA (Etapa 8)** — saída só via schema validado; nunca executa; permissões perigosas exigem revisão humana.
12. **Privacidade na clonagem (Etapa 7)** — exporta só estrutura (nomes, ordem, cores, overwrites); sem mensagens, membros ou segredos.

## Limitações desta Etapa 0

- discord.py não está instalado neste ambiente (rede desativada para instalação); nenhuma chamada à API real foi feita. Validei apenas o schema com pydantic e pytest, já instalados.
- Constantes de limites acima devem ser confirmadas na Etapa 1/5.
