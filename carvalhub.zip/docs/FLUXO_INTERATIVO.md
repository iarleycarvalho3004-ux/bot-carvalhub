# Fluxo interativo

## Máquina de estados da sessão

```
INÍCIO ─► ESCOLHA_ESTILO ─► ESCOLHA_PORTE ─► MÓDULOS/IDENTIDADE ─► PRÉVIA ◄──► EDITOR
                                                                      │
                                                  [Cancelar] ─► CANCELADA
                                                  [Expirou]  ─► EXPIRADA
                                                  [GERAR]    ─► CONFIRMAÇÃO_FINAL ─► EXECUTANDO ─► CONCLUÍDA | PARCIAL
                                                                                                      │
                                                                       [Retomar] / [Limpar (confirma)]
```

## Telas (todas ephemeral para o administrador da sessão)

1. **/criar-servidor** — pré-checagem: usuário tem Administrator? bot tem permissões? Se não, explica o que falta (nada é criado).
2. **Estilos** — select de família (6) → select de template (≤25 opções, paginado) com selo de status (✅ completo / 🧪 experimental / 🚧 em desenvolvimento) + opção "Modelo em branco".
3. **Porte** — 3 botões: Compacto / Equilibrado / Completo, com contagem estimada de elementos.
4. **Módulos e identidade** — select múltiplo de módulos (⏳ para não implementados, desabilitados); botão Identidade abre modal (nome do servidor, formato de nome, idioma, estilo visual).
5. **Prévia** — páginas de embed (categorias/canais; cargos; permissões resumidas e alertas; resumo e contagens). Botões: ◀ ▶ [Editar] [Voltar] [Cancelar] [GERAR SERVIDOR]. "Gerar" fica desabilitado enquanto a validação tiver erros e mostra os erros.
6. **Editor** (Etapa 6) — select de ação; modals para renomear/adicionar; botões ↑ ↓ para ordem; cada alteração revalida e redesenha a prévia.
7. **Confirmação final** — nome do servidor, nº de cargos/categorias/canais, avisos sensíveis; botões [Confirmar e criar] [Voltar].
8. **Progresso** — mensagem editada periodicamente (barra + etapa atual), com limite de frequência.
9. **Relatório** — ✅ criados, ⚠️ avisos, ❌ falhas; em parcial: [Retomar] [Limpar o que foi criado] (confirmação explícita extra).

## Regras de segurança da interface

- Todo componente valida `user_id` da sessão e estado/expiração antes de agir.
- Expiração padrão: 30 min de inatividade; botão Cancelar em todas as telas.
- Prévia paginada: ≤ 4000 caracteres de descrição por embed (margem sob o limite de 4096), ≤ 6000 por mensagem, ≤ 25 opções por select.
- Ação destrutiva (limpeza) sempre exige segunda confirmação e só afeta `created_elements` da operação.

## Comandos e etapa em que passam a existir

| Comando | Etapa |
|---|---|
| /painel, /ajuda, /status | 1 |
| /modelos | 2 |
| /criar-servidor | 3 (assistente) → 5 (geração real) |
| /meus-modelos, /salvar-modelo, /backup, /restaurar | 7 |

Comandos de etapas futuras **não** são registrados antes de existirem.
