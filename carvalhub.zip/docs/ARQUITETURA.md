# SERVER BUILDER — Arquitetura (Etapa 0)

## 1. Princípios

1. **Plano como dado.** Todo o fluxo gira em torno de um `BuildPlan` (JSON validado por pydantic). A prévia, o editor, o validador e o executor leem o mesmo objeto. Assim a prévia é, por construção, fiel ao que será criado.
2. **Nada real sem confirmação.** Só o `executor` fala com a API para criar/alterar/apagar, e só é chamado a partir do botão "Gerar servidor" (com confirmação final).
3. **Estado persistente.** Sessões, planos e operações ficam no banco; botões usam `custom_id` com ID de sessão e views persistentes, sobrevivendo a reinícios.
4. **Camadas finas, sem dependência circular.** `commands` (UI/Discord) → `modules` (regras) → `database` / `utils`. Módulos de regra não importam `discord` exceto o `executor` e `permissions` (adaptadores).
5. **IA, clonagem e módulos extras desacoplados.** Produzem `BuildPlan`; nunca executam por conta própria.

## 2. Camadas e responsabilidades

| Camada | Pasta | Responsabilidade | Importa discord? |
|---|---|---|---|
| Entrada | `bot.py`, `commands/` | Slash commands, views, modals, paginação, checagem de autor | Sim |
| Domínio | `modules/templates` | Schema, loader, catálogo, filtros | Não |
| Domínio | `modules/builder/session.py` | Ciclo de vida da sessão, expiração, autorização | Não |
| Domínio | `modules/builder/validation.py` | Limites, nomes, duplicidades, hierarquia, permissões | Não |
| Domínio | `modules/builder/preview.py` | Renderiza plano → páginas de embed (texto puro + limites) | Não (gera estruturas simples) |
| Infra | `modules/builder/executor.py` | Criação real, progresso, retomada, limpeza | Sim |
| Infra | `modules/permissions` | Mapeia nomes de permissão do schema → `discord.Permissions`; detecta permissões perigosas | Sim (fino) |
| Persistência | `database/` | Conexão (SQLite/Postgres), modelos, migrações | Não |
| Transversal | `utils/` | Logger com rotação (mascara token), erros tipados, helpers de nomes | Não |
| Futuro | `modules/cloning`, `backup`, `ai` | Etapas 7 e 8 | — |

Regra: testes unitários cobrem tudo que **não** importa `discord` (maioria da lógica), sem precisar de token.

## 3. Fluxo de dados

```
Template (JSON) ──► loader/catalog ──► BuildPlan inicial
                                         │  (porte + módulos + identidade aplicados por função pura)
                          sessão (DB) ◄──┤
                                         ▼
                    editor (botões/modals) altera BuildPlan ──► validation ──► preview (páginas)
                                         │
                       "Gerar servidor" ─┴─► validação final ─► confirmação ─► executor
                                                                              │
                                      operations + created_elements (DB) ◄────┘
```

`BuildPlan` = template já resolvido (porte, módulos, estilo de nome, idioma) + edições do usuário. A "restauração da versão inicial" recalcula a partir do template + opções iniciais.

## 4. Modelo de dados (resumo; DDL em `database/migrations/0001_initial.sql` na Etapa 1)

Compatível com SQLite (dev) e PostgreSQL (prod): tipos simples, JSON guardado como TEXT/JSONB via camada de conexão, IDs Discord como `BIGINT`/INTEGER.

- **guild_settings**(guild_id PK, language, style, created_at, updated_at)
- **build_sessions**(id PK uuid, guild_id, user_id, template_id, plan_json, state, step, created_at, updated_at, expires_at) — índice (guild_id, user_id, state); `state` ∈ {active, confirmed, cancelled, expired}. Unicidade: no máximo 1 sessão `active` por (guild_id, user_id).
- **operations**(id PK uuid, session_id FK, guild_id, user_id, status, plan_hash, started_at, finished_at, error) — `status` ∈ {pending, running, partial, completed, failed, cleaned}.
- **created_elements**(id PK, operation_id FK, kind {role, category, channel}, plan_key, discord_id, name, created_at, deleted_at NULL) — UNIQUE(operation_id, plan_key): garante retomada sem duplicar e limpeza só do que a operação criou.
- **user_templates**(id PK, owner_id, name, plan_json, created_at) — UNIQUE(owner_id, name). (Etapa 7)
- **backups**(id PK, guild_id, version, label, structure_json, created_by, created_at) — UNIQUE(guild_id, version). (Etapa 7)
- **audit_log**(id PK, guild_id, user_id, action, detail_json, created_at) — índice (guild_id, created_at).
- **schema_migrations**(version PK, applied_at).

Nunca armazenado: token do Discord, conteúdo de mensagens, dados de membros.

## 5. Sessões

- TTL padrão 30 min de inatividade (renovado a cada interação), configurável.
- `custom_id` = `sb:{session_id_curto}:{ação}`; todo handler: carrega sessão → verifica `interaction.user.id == session.user_id` → verifica estado/expiração → age. Outros usuários recebem resposta ephemeral negando.
- Mensagens ephemeral só podem ser editadas durante a vida do token de interação (15 min). Estratégia: a cada interação, responder via `interaction.response.edit_message`; se o token expirou, o painel reenvia uma nova mensagem ephemeral por `/painel` ("Continuar sessão"), usando o plano salvo no banco.
- Tarefa de limpeza periódica marca sessões vencidas como `expired`.

## 6. Executor (Etapa 5, desenhado agora)

Ordem: validação final → cargos (do mais baixo para o mais alto, respeitando posição abaixo do cargo do bot) → categorias → canais → overwrites → módulos. Cada elemento criado é gravado em `created_elements` **imediatamente** após o retorno da API. Retomada: pula `plan_key` já presentes. Limpeza: apaga somente linhas de `created_elements` da operação, com confirmação explícita; nada preexistente é tocado. Rate limit: discord.py trata 429; o executor adiciona pausa curta entre criações e reporta progresso a cada N itens (edição de mensagem com limite de frequência).

## 7. Dependências planejadas (versões fixadas na Etapa 1, após teste de instalação)

discord.py 2.x, aiosqlite, asyncpg, pydantic 2.x, python-dotenv, pytest, pytest-asyncio. SQLAlchemy **não** será usado por ora: SQL simples com uma camada fina cobre as necessidades, evitando complexidade (revisável).

## 8. Decisões que ajustam a estrutura sugerida

- Adicionados `modules/templates/schema.py` (modelos pydantic) e `docs/`.
- `modules/builder/naming.py` (estilos de nome) entra na Etapa 3, sem alterar a estrutura de pastas.
- Templates ficam em `templates/<família>/<id>.json`; novos templates = novo arquivo, sem mudar código.

## 9. Escopo de intents

Somente `Guilds` (intents default sem `members` nem `message_content`). Slash commands/componentes não exigem intents privilegiadas.
