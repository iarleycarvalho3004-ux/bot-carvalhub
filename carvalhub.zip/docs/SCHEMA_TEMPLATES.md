# Schema dos templates

Implementado em `modules/templates/schema.py` (pydantic v2). Exemplo validado: `templates/community/comunidade-geral.json`.

## Campos do template

| Campo | Descrição |
|---|---|
| `id` | Slug estável e único (`^[a-z0-9][a-z0-9-]{1,63}$`). Nunca muda após publicado. |
| `schema_version` | Inteiro; permite migrar templates futuros. |
| `name`, `description` | Texto exibido no catálogo. |
| `family` | `community`, `gaming`, `creator`, `education`, `business`, `specialized`. |
| `status` | `complete`, `experimental` ou `in_development` — exibido na interface. |
| `audience` | Público recomendado. |
| `recommended_size` | `compact`, `balanced` ou `full`. |
| `roles[]` | `key`, `name`, `color`, `hoist`, `mentionable`, `permissions[]`, `min_size`, `sensitive_ack`. A **ordem da lista = hierarquia** (primeiro é o mais alto). |
| `categories[]` | `key`, `name`, `emoji`, `min_size`, `module` (opcional), `overwrites[]`, `channels[]`. |
| `channels[]` | `key`, `name` (slug sem formatação), `type` (`text`, `voice`, `announcement`, `forum`, `stage`), `topic`, `emoji`, `min_size`, `module`, `overwrites[]`, `slowmode`, `user_limit` (voz), `nsfw`. |
| `overwrites[]` | `role` (chave de cargo ou `@everyone`), `allow[]`, `deny[]`. Canal privado = `deny view_channel` para `@everyone` + `allow` para cargos específicos. |
| `modules[]` | `key`, `name`, `description`, `default_enabled`, `requires_external` (bool), `implemented` (bool). Módulos com `implemented=false` aparecem como "em breve" e não podem ser marcados como funcionais. |
| `initial_messages[]` | `channel` (chave), `content` (≤2000), `module`. Etapa 5+ (opcional). |
| `warnings[]` | Alertas e requisitos (ex.: "Canais de anúncio e fórum exigem o modo Comunidade ativo"). |

## Regras de validação do schema (aplicadas automaticamente)

- Chaves únicas dentro de cada coleção; overwrites só referenciam cargos existentes ou `@everyone`.
- Nomes de permissão pertencem a uma lista permitida; permissões **perigosas** (`administrator`, `manage_guild`, `manage_roles`, `manage_channels`, `manage_webhooks`, `ban_members`, `kick_members`, `mention_everyone`, `manage_messages`, `moderate_members` etc.) exigem `sensitive_ack: true` e geram alerta na prévia. `administrator` é **rejeitado** em cargos que não sejam o cargo marcado `owner_like`, e mesmo nele exige reconhecimento explícito.
- Limites: nome de cargo ≤100, canal ≤100, categoria ≤100, tópico ≤1024, cor 0x000000–0xFFFFFF, ≤50 canais por categoria.
- Totais (após aplicar porte e módulos): ≤250 cargos e ≤500 canais+categorias (limites da plataforma); o validador de plano checa o resultado final, não só o template bruto.
- `min_size` filtra por porte: `compact` ⊂ `balanced` ⊂ `full` (um item `balanced` aparece em balanced e full).

## Como o porte e os módulos são aplicados

`resolve(template, size, enabled_modules, identity) -> BuildPlan`: filtra por `min_size`, remove itens cujo `module` não esteja ativo, aplica estilo de nome (`#geral`, `#・geral`, `#┃geral`, `#﹒geral`, `#»geral`), idioma e emoji. Função pura, testável sem Discord.

## Estimativa de elementos

Calculada, não digitada: `len(roles) + len(categories) + len(channels)` do plano resolvido.
