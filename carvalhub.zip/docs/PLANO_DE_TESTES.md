# Plano de testes

Ferramentas: pytest, pytest-asyncio. Banco de testes: SQLite em memória (e Postgres na Etapa 10).

## Níveis

1. **Unitários (sem Discord, sem token)** — schema, resolução de porte/módulos, estilos de nome, validação de plano, paginador de prévia, sessão (expiração/autorização), mapeamento de permissões.
2. **Banco** — migrações aplicam do zero; restrições UNIQUE/FK; persistência após "reinício" (reabrir conexão e reler sessão).
3. **Integração com mocks do discord.py** — handlers de comandos/views com `Interaction` simulada: autor errado é negado; sessão expirada; botão Gerar bloqueado com erros.
4. **Servidor de teste real (manual, documentado)** — Etapa 1: bot conecta, comandos respondem. Etapa 5: criação completa, falha forçada (remover permissão no meio), retomada, limpeza.

## Matriz por etapa

| Etapa | Testes obrigatórios |
|---|---|
| 0 | `tests/test_templates.py`: template de exemplo válido; casos inválidos rejeitados (chave duplicada, overwrite para cargo inexistente, administrator sem aval, cor fora da faixa, id inválido) |
| 1 | Config sem token falha com mensagem clara; token nunca aparece em logs; DB persiste após reiniciar; /status reporta DB |
| 2 | Todos os JSON em `templates/` validam; ids únicos; filtros por família/porte |
| 3 | Sessão só manipulável pelo autor; expiração; persistência após reinício |
| 4 | Prévia = contagens do plano; paginação respeita limites com plano de 250 cargos/500 canais; prévia atualiza após edição |
| 5 | Ordem de criação; IDs gravados; sem duplicar ao retomar; limpeza só toca elementos da operação; bot sem permissão é bloqueado na validação |
| 6 | Cada operação de edição mantém plano válido; restaurar template inicial |
| 7 | Exportar→importar é idempotente (round-trip); backup não contém mensagens/membros/segredos |
| 8 | JSON da IA inválido é rejeitado; IA nunca chama executor |
| 9 | Cada módulo ativa/desativa sem quebrar plano |
| 10 | Deploy limpo via Docker; migrações em Postgres; restauração de backup do banco |

## Como rodar (Etapa 0)

```
cd server-builder
python -m pytest -q
```

Regra: nenhum resultado é reportado sem execução real.
