-- 0001: configurações por guild e auditoria (Etapa 1).
-- Tabelas de sessões, operações, modelos e backups entram em migrações futuras.

CREATE TABLE guild_settings (
    guild_id    BIGINT PRIMARY KEY,
    language    TEXT NOT NULL DEFAULT 'pt',
    style       TEXT NOT NULL DEFAULT 'clean',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE TABLE audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id    BIGINT,
    user_id     BIGINT,
    action      TEXT NOT NULL,
    detail_json TEXT,
    created_at  TEXT NOT NULL
);

CREATE INDEX idx_audit_log_guild_created ON audit_log (guild_id, created_at);
