"""Camada de banco de dados assíncrona.

Desenvolvimento: SQLite via módulo padrão `sqlite3`, executado em thread
(asyncio.to_thread) para não bloquear o loop de eventos.
Produção: PostgreSQL será adicionado na Etapa 10 atrás desta mesma interface.
"""
from __future__ import annotations

import asyncio
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

from utils.errors import ConfigError, DatabaseError

log = logging.getLogger(__name__)

MIGRATIONS_DIR = Path(__file__).parent / "migrations"


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _sqlite_path(url: str) -> str:
    prefix = "sqlite:///"
    if not url.startswith(prefix):
        raise ConfigError(
            "DATABASE_URL não suportada nesta etapa. Use 'sqlite:///caminho/arquivo.db'. "
            "PostgreSQL será habilitado na Etapa 10."
        )
    path = url[len(prefix):]
    if not path:
        raise ConfigError("DATABASE_URL do SQLite sem caminho de arquivo.")
    return path


class Database:
    def __init__(self, url: str) -> None:
        self._path = _sqlite_path(url)
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    # ---- ciclo de vida ----
    async def connect(self) -> None:
        if self._conn is not None:
            return
        await asyncio.to_thread(self._connect)
        log.info("Banco conectado (sqlite).")

    def _connect(self) -> None:
        if self._path != ":memory:":
            Path(self._path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self._path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        if self._path != ":memory:":
            conn.execute("PRAGMA journal_mode = WAL")
        self._conn = conn

    async def close(self) -> None:
        if self._conn is None:
            return
        async with self._lock:
            conn, self._conn = self._conn, None
            await asyncio.to_thread(conn.close)
        log.info("Banco fechado.")

    def _require(self) -> sqlite3.Connection:
        if self._conn is None:
            raise DatabaseError("Banco não conectado. Chame connect() primeiro.")
        return self._conn

    # ---- consultas ----
    async def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        """Executa uma escrita e faz commit. Retorna o número de linhas afetadas."""
        async with self._lock:
            return await asyncio.to_thread(self._execute, sql, tuple(params))

    def _execute(self, sql: str, params: tuple) -> int:
        conn = self._require()
        try:
            cur = conn.execute(sql, params)
            conn.commit()
            return cur.rowcount
        except sqlite3.Error as exc:
            conn.rollback()
            raise DatabaseError(f"Erro ao executar SQL: {exc}") from exc

    async def fetchone(self, sql: str, params: Sequence[Any] = ()) -> dict | None:
        async with self._lock:
            return await asyncio.to_thread(self._fetch, sql, tuple(params), True)

    async def fetchall(self, sql: str, params: Sequence[Any] = ()) -> list[dict]:
        async with self._lock:
            return await asyncio.to_thread(self._fetch, sql, tuple(params), False)

    def _fetch(self, sql: str, params: tuple, one: bool):
        conn = self._require()
        try:
            cur = conn.execute(sql, params)
            if one:
                row = cur.fetchone()
                return dict(row) if row else None
            return [dict(r) for r in cur.fetchall()]
        except sqlite3.Error as exc:
            raise DatabaseError(f"Erro ao consultar SQL: {exc}") from exc

    async def ping(self) -> bool:
        try:
            row = await self.fetchone("SELECT 1 AS ok")
            return bool(row and row["ok"] == 1)
        except DatabaseError:
            return False

    # ---- migrações ----
    async def migrate(self) -> list[str]:
        """Aplica migrações pendentes em ordem. Retorna as versões aplicadas agora."""
        async with self._lock:
            return await asyncio.to_thread(self._migrate)

    def _migrate(self) -> list[str]:
        conn = self._require()
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations ("
            "version TEXT PRIMARY KEY, applied_at TEXT NOT NULL)"
        )
        conn.commit()
        done = {r["version"] for r in conn.execute("SELECT version FROM schema_migrations")}
        applied: list[str] = []
        for file in sorted((MIGRATIONS_DIR / "sqlite").glob("*.sql")):
            version = file.stem
            if version in done:
                continue
            script = file.read_text(encoding="utf-8")
            try:
                conn.executescript(
                    "BEGIN;\n" + script + "\n"
                    f"INSERT INTO schema_migrations (version, applied_at) "
                    f"VALUES ('{version}', '{utcnow()}');\nCOMMIT;"
                )
            except sqlite3.Error as exc:
                conn.rollback()
                raise DatabaseError(f"Falha na migração {version}: {exc}") from exc
            applied.append(version)
            log.info("Migração aplicada: %s", version)
        return applied

    # ---- helpers de domínio (Etapa 1) ----
    async def ensure_guild(self, guild_id: int) -> None:
        now = utcnow()
        await self.execute(
            "INSERT INTO guild_settings (guild_id, created_at, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET updated_at = excluded.updated_at",
            (guild_id, now, now),
        )

    async def audit(self, action: str, guild_id: int | None = None,
                    user_id: int | None = None, detail_json: str | None = None) -> None:
        await self.execute(
            "INSERT INTO audit_log (guild_id, user_id, action, detail_json, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (guild_id, user_id, action, detail_json, utcnow()),
        )
