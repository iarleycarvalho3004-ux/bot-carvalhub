"""Logging com rotação de arquivos e mascaramento de segredos."""
from __future__ import annotations

import logging
import re
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Iterable

# Formato típico de token de bot: <id base64>.<timestamp>.<hmac>
TOKEN_RE = re.compile(r"[A-Za-z0-9_-]{23,28}\.[A-Za-z0-9_-]{6,7}\.[A-Za-z0-9_-]{27,}")
REDACTED = "[REDACTED]"

_HANDLER_TAG = "_server_builder_handler"


class RedactingFormatter(logging.Formatter):
    """Formata o registro completo (inclusive traceback) e mascara segredos."""

    def __init__(self, *args, secrets: Iterable[str] = (), **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._secrets = [s for s in secrets if s]

    def redact(self, text: str) -> str:
        for secret in self._secrets:
            text = text.replace(secret, REDACTED)
        return TOKEN_RE.sub(REDACTED, text)

    def format(self, record: logging.LogRecord) -> str:
        return self.redact(super().format(record))


def setup_logging(
    level: str = "INFO",
    log_dir: Path | str = "logs",
    secrets: Iterable[str] = (),
    max_bytes: int = 5 * 1024 * 1024,
    backup_count: int = 5,
) -> None:
    """Configura o logger raiz: console + arquivo rotativo. Idempotente."""
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    for h in list(root.handlers):
        if getattr(h, _HANDLER_TAG, False):
            root.removeHandler(h)
            h.close()

    fmt = RedactingFormatter(
        "%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        secrets=list(secrets),
    )

    console = logging.StreamHandler()
    file_handler = RotatingFileHandler(
        log_dir / "server_builder.log",
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    for h in (console, file_handler):
        h.setFormatter(fmt)
        setattr(h, _HANDLER_TAG, True)
        root.addHandler(h)

    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    # Mantém bibliotecas ruidosas em nível razoável.
    logging.getLogger("discord").setLevel(logging.INFO)
    logging.getLogger("discord.http").setLevel(logging.WARNING)
