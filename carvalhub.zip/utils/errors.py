"""Erros tipados do projeto."""


class ServerBuilderError(Exception):
    """Base de todos os erros do projeto."""


class ConfigError(ServerBuilderError):
    """Configuração ausente ou inválida."""


class DatabaseError(ServerBuilderError):
    """Falha na camada de banco de dados."""
