"""Ponto de entrada do CARVALHUB / SERVER BUILDER."""
from __future__ import annotations

import logging
import time

import discord
from discord import app_commands
from discord.ext import commands

from config import Settings
from database.connection import Database
from utils.errors import ConfigError
from utils.logger import setup_logging

log = logging.getLogger("server_builder")

EXTENSIONS = ("commands.general",)


class ServerBuilderBot(commands.Bot):
    def __init__(self, settings: Settings, db: Database) -> None:
        # Somente a intent "guilds": slash commands e componentes não exigem intents privilegiadas.
        intents = discord.Intents.none()
        intents.guilds = True
        super().__init__(command_prefix=commands.when_mentioned, intents=intents, help_command=None)
        self.settings = settings
        self.db = db
        self.started_at = time.monotonic()
        self.tree.on_error = self.on_app_command_error

    async def setup_hook(self) -> None:
        await self.db.connect()
        applied = await self.db.migrate()
        if applied:
            log.info("Migrações aplicadas na inicialização: %s", applied)
        for ext in EXTENSIONS:
            await self.load_extension(ext)
        synced = await self.tree.sync()
        log.info("Comandos sincronizados: %s", [c.name for c in synced])

    async def on_ready(self) -> None:
        log.info("Conectado como %s em %d servidor(es).", self.user, len(self.guilds))

    async def close(self) -> None:
        await super().close()
        await self.db.close()

    async def on_app_command_error(
        self, interaction: discord.Interaction, error: app_commands.AppCommandError
    ) -> None:
        if isinstance(error, app_commands.MissingPermissions):
            message = "Você precisa ser administrador do servidor para usar este comando."
        elif isinstance(error, app_commands.NoPrivateMessage):
            message = "Este comando só funciona dentro de um servidor."
        else:
            log.exception("Erro em comando %s", interaction.command, exc_info=error)
            message = "Ocorreu um erro inesperado. Tente novamente em instantes."
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)


def main() -> None:
    try:
        settings = Settings.from_env()
    except ConfigError as exc:
        raise SystemExit(f"Erro de configuração: {exc}")

    setup_logging(settings.log_level, settings.log_dir, secrets=[settings.discord_token])
    bot = ServerBuilderBot(settings, Database(settings.database_url))
    # log_handler=None: usamos o nosso logging (com mascaramento de token).
    bot.run(settings.discord_token, log_handler=None)


if __name__ == "__main__":
    main()
