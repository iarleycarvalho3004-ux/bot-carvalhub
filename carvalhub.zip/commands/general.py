"""Comandos gerais: /painel, /ajuda, /status (Etapa 1)."""
from __future__ import annotations

import logging
import time

import discord
from discord import app_commands
from discord.ext import commands

log = logging.getLogger(__name__)

BRAND_COLOR = 0x7B2FF7  # roxo da logo CARVALHUB

# Estado honesto de cada recurso, conforme o plano de etapas.
FEATURES = (
    ("Bot, banco e logs", "✅ Disponível"),
    ("Catálogo de modelos (/modelos)", "🚧 Em desenvolvimento (Etapa 2)"),
    ("Assistente e prévia (/criar-servidor)", "🚧 Em desenvolvimento (Etapas 3–4)"),
    ("Criação real da estrutura", "🚧 Em desenvolvimento (Etapa 5)"),
    ("Backup, clonagem e modelos pessoais", "🚧 Em desenvolvimento (Etapa 7)"),
    ("IA opcional", "🚧 Em desenvolvimento (Etapa 8)"),
)


def format_uptime(seconds: float) -> str:
    seconds = int(seconds)
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours or days:
        parts.append(f"{hours}h")
    if minutes or hours or days:
        parts.append(f"{minutes}min")
    parts.append(f"{secs}s")
    return " ".join(parts)


class General(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name="painel", description="Abre o painel principal do CARVALHUB.")
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def painel(self, interaction: discord.Interaction) -> None:
        await self.bot.db.ensure_guild(interaction.guild_id)
        await self.bot.db.audit("painel_aberto", interaction.guild_id, interaction.user.id)
        embed = discord.Embed(
            title="CARVALHUB — Painel",
            description="Construtor de estruturas para servidores Discord.\n"
                        "Nada é criado no seu servidor sem confirmação explícita.",
            color=BRAND_COLOR,
        )
        for name, state in FEATURES:
            embed.add_field(name=name, value=state, inline=False)
        embed.set_footer(text="Use /ajuda para saber mais · /status para diagnóstico")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="ajuda", description="Explica como usar o CARVALHUB.")
    async def ajuda(self, interaction: discord.Interaction) -> None:
        embed = discord.Embed(
            title="Ajuda — CARVALHUB",
            description=(
                "O CARVALHUB monta categorias, canais e cargos dentro de um servidor "
                "que **você já criou**. Ele não cria servidores novos.\n\n"
                "**Comandos disponíveis agora**\n"
                "• `/painel` — painel principal (administradores)\n"
                "• `/ajuda` — esta mensagem\n"
                "• `/status` — diagnóstico do bot e do banco (administradores)\n\n"
                "Os demais comandos (modelos, criar servidor, backup) serão liberados "
                "conforme cada etapa ficar pronta."
            ),
            color=BRAND_COLOR,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="status", description="Mostra o estado do bot e do banco.")
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def status(self, interaction: discord.Interaction) -> None:
        db_ok = await self.bot.db.ping()
        latency_ms = round(self.bot.latency * 1000)
        uptime = format_uptime(time.monotonic() - self.bot.started_at)
        embed = discord.Embed(
            title="Status",
            color=BRAND_COLOR if db_ok else 0xE74C3C,
        )
        embed.add_field(name="Latência", value=f"{latency_ms} ms")
        embed.add_field(name="Banco de dados", value="✅ OK" if db_ok else "❌ Falha")
        embed.add_field(name="Tempo ligado", value=uptime)
        embed.add_field(name="Servidores", value=str(len(self.bot.guilds)))
        embed.add_field(name="Ambiente", value=self.bot.settings.environment)
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(General(bot))
