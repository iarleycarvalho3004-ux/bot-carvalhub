"""Configuração do bot, lida de variáveis de ambiente (e do arquivo .env, se existir)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping

from utils.errors import ConfigError

PLACEHOLDER_TOKENS = {"", "COLE_SEU_TOKEN_AQUI", "your_token_here", "changeme"}
VALID_ENVIRONMENTS = {"development", "production"}
VALID_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
DEFAULT_DATABASE_URL = "sqlite:///data/server_builder.db"


@dataclass(frozen=True)
class Settings:
    # repr=False: o token nunca aparece em prints/logs acidentais.
    discord_token: str = field(repr=False)
    database_url: str = DEFAULT_DATABASE_URL
    environment: str = "development"
    log_level: str = "INFO"
    log_dir: Path = Path("logs")

    @classmethod
    def from_env(
        cls,
        env: Mapping[str, str] | None = None,
        load_dotenv_file: bool = True,
    ) -> "Settings":
        if env is None:
            if load_dotenv_file:
                try:
                    from dotenv import load_dotenv

                    load_dotenv()
                except ImportError:  # python-dotenv é opcional em tempo de execução
                    pass
            env = os.environ

        token = (env.get("DISCORD_TOKEN") or "").strip()
        if token in PLACEHOLDER_TOKENS:
            raise ConfigError(
                "DISCORD_TOKEN não configurado. Copie .env.example para .env e preencha "
                "com o token do bot (Discord Developer Portal → Bot → Reset Token)."
            )

        environment = (env.get("ENVIRONMENT") or "development").strip().lower()
        if environment not in VALID_ENVIRONMENTS:
            raise ConfigError(
                f"ENVIRONMENT inválido: '{environment}'. Use um de {sorted(VALID_ENVIRONMENTS)}."
            )

        log_level = (env.get("LOG_LEVEL") or "INFO").strip().upper()
        if log_level not in VALID_LOG_LEVELS:
            raise ConfigError(
                f"LOG_LEVEL inválido: '{log_level}'. Use um de {sorted(VALID_LOG_LEVELS)}."
            )

        database_url = (env.get("DATABASE_URL") or DEFAULT_DATABASE_URL).strip()
        log_dir = Path((env.get("LOG_DIR") or "logs").strip())

        return cls(
            discord_token=token,
            database_url=database_url,
            environment=environment,
            log_level=log_level,
            log_dir=log_dir,
        )
